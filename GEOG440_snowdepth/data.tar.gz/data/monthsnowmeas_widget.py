#Creates the Timeseries Widget in the Notebook
# jkroundy@ku.edu July 2020

import numpy as np #This is main numerical library used in python
import matplotlib.pyplot as plt #This is the main plotting library used in python
from ipywidgets import *
import data.datafun as dfun 

#Widget Functions
def tupdate(yr):
	idx = (wy > yr -2)*(wy < yr + 2)
	xx = x[idx]
	ax1.set_xlim(xx.min(),xx.max())
	ax2.set_xlim(xx.min(),xx.max())
	ax3.set_xlim(xx.min(),xx.max())
	fig.canvas.draw_idle()    

def sleepers(sid):
	lineS1.set_visible(sid)
	lineS2.set_visible(sid)
	lineS3.set_visible(sid)

def reynolds(rid):
	lineR1.set_visible(rid)
	lineR2.set_visible(rid)
	lineR3.set_visible(rid)

def savfigtm(sid):
	swyr = year.value
	pname = "snow_monthly_"+str(swyr)+".png"
	fname = "./figures/"+pname
	fig.savefig(fname, dpi=150) 
	print("Figure: "+pname+" saved to Figures folder.")

Q,SWE,SND,wy,mtime,xstr,tidx,nm = dfun.get_monthly_data()

#Create Initial Plots
fig = plt.figure(figsize=(9,9))
ax1 = fig.add_subplot(3, 1, 3)
x = np.arange(nm)
lineS1, = ax1.plot(x,Q[:,0],color='#f1cbd5',label='Sleepers')
lineR1, = ax1.plot(x,Q[:,1],color='#821f48',label='Reynolds')
ax1.set_ylabel('Streamflow [cfs]')
ax1.set_xticks(x[tidx])
ax1.set_xticklabels(xstr[tidx])
ax1.set_xlim(x.min(),x.max())
ax1.set_ylim(np.nanmin(Q),np.nanmax(Q))
plt.legend(loc=1,ncol=2,fontsize=10); 

ax2 = fig.add_subplot(3, 1, 2)
lineS2, = ax2.plot(x,SWE[:,0],color='#69ef7b',label='Sleepers')
lineR2, = ax2.plot(x,SWE[:,1],color='#02531d',label='Reynolds')
ax2.set_ylabel('SWE [mm]')
ax2.set_xticks(x[tidx])
ax2.set_xticklabels(xstr[tidx])
ax2.set_xlim(x.min(),x.max())
ax2.set_ylim(np.nanmin(SWE),np.nanmax(SWE))
plt.legend(loc=1,ncol=2,fontsize=10); 

ax3 = fig.add_subplot(3, 1, 1)
lineS3, = ax3.plot(x,SND[:,0],color='#79e3f9',label='Sleepers')
lineR3, = ax3.plot(x,SND[:,1],color='#256676',label='Reynolds')
ax3.set_ylabel('Snow Depth [mm]')
ax3.set_xticks(x[tidx])
ax3.set_xticklabels(xstr[tidx])
ax3.set_xlim(x.min(),x.max())
ax3.set_ylim(np.nanmin(SND),np.nanmax(SND))
plt.legend(loc=1,ncol=2,fontsize=10); 
plt.subplots_adjust(hspace=0.3)

# Activate Widgets
year = widgets.IntSlider(min=2001, max=2013, step=1, value=2001)
interact(tupdate, yr=year);
interact(sleepers, sid = widgets.Checkbox(value=True, description='Sleepers River', disabled=False, indent=False));
interact(reynolds, rid = widgets.Checkbox(value=True, description='Reynolds Creek', disabled=False, indent=False));
button = Button(description="Save Figure")
display(button)
button.on_click(savfigtm,)

