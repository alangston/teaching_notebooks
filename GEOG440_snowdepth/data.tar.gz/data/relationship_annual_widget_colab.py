#Creates the Daily Snow Measurment Widget in the Notebook
# jkroundy@ku.edu July 2020

import numpy as np #This is main numerical library used in python
import matplotlib.pyplot as plt #This is the main plotting library used in python
from ipywidgets import *
import data.datafun as dfun

#Widget functions
def savfigtm(sid):
    xstr = xdd.value
    xstr = xstr.replace(" ", "_")
    ystr = ydd.value
    ystr = ystr.replace(" ", "_")
    
    pname = "rel_annual_"+xstr+"_"+ystr+".png"
    fname = "./figures/"+pname
    fig.savefig(fname, dpi=150) 
    print("Saved Figure: "+pname)

def annualscat(xp,yp):
	if xp =="Peak Snow Depth":
		x1 = SNDp[:,0]
		x2 = SNDp[:,1]
		xstr = "Peak Snow Depth [mm]"
	elif xp == "Peak SWE":
		x1 = SWEp[:,0]
		x2 = SWEp[:,1]
		xstr = "Peak SWE [mm]"
	elif xp == "Peak Streamflow":
		x1 = Qp[:,0]
		x2 = Qp[:,1]
		xstr = "Peak Streamflow [cfs]"
	elif xp == "DOY of Peak Streamflow":
		x1 = dQp[:,0]
		x2 = dQp[:,1]
		xstr = "DOY of Peak Streamflow"        
	elif xp == "DOY of Peak Snow Depth":
		x1 = dSNDp[:,0]
		x2 = dSNDp[:,1]
		xstr = "DOY of Peak Snow Depth"
	elif xp == "DOY of Peak SWE":
		x1 = dSWEp[:,0]
		x2 = dSWEp[:,1]
		xstr = "DOY of Peak SWE"
	elif xp == "DOY of First Snow":
		x1 = dfs[:,0]
		x2 = dfs[:,1]
		xstr = "DOY of First Snow"
	elif xp == "DOY of Last Snow":
		x1 = dls[:,0]
		x2 = dls[:,1]
		xstr = "DOY of Last Snow"

	if yp =="Peak Snow Depth":
		y1 = SNDp[:,0]
		y2 = SNDp[:,1]
		ystr = "Peak Snow Depth [mm]"
	elif yp == "Peak SWE":
		y1 = SWEp[:,0]
		y2 = SWEp[:,1]
		ystr = "Peak SWE [mm]"
	elif yp == "Peak Streamflow":
		y1 = Qp[:,0]
		y2 = Qp[:,1]
		ystr = "Peak Streamflow [cfs]"
	elif yp == "DOY of Peak Streamflow":
		y1 = dQp[:,0]
		y2 = dQp[:,1]
		ystr = "DOY of Peak Streamflow"        
	elif yp == "DOY of Peak Snow Depth":
		y1 = dSNDp[:,0]
		y2 = dSNDp[:,1]
		ystr = "DOY of Peak Snow Depth"
	elif yp == "DOY of Peak SWE":
		y1 = dSWEp[:,0]
		y2 = dSWEp[:,1]
		ystr = "DOY of Peak SWE"
	elif yp == "DOY of First Snow":
		y1 = dfs[:,0]
		y2 = dfs[:,1]
		ystr = "DOY of First Snow"
	elif yp == "DOY of Last Snow":
		y1 = dls[:,0]
		y2 = dls[:,1]
		ystr = "DOY of Last Snow"

	global fig
	#Create Initial Plots
	fig = plt.figure(figsize=(9,4))
	bf = 10
	ax1 = fig.add_subplot(1, 2, 1)
	ln1, = ax1.plot(x1,y1,color=[0,0,0],linestyle='',linewidth=2,marker='o',markerfacecolor=[0,1,0],markersize=6) #plot data
	ax1.set_xlabel(xstr)
	ax1.set_ylabel(ystr)
	ax1.set_xlim(np.nanmin(x1)-bf,np.nanmax(x1)+bf)
	ax1.set_ylim(np.nanmin(y1)-bf,np.nanmax(y1)+bf)
	ax1.set_title('Sleepers River');

	ax2 = fig.add_subplot(1, 2, 2)
	ln2, = ax2.plot(x2,y2,color=[0,0,0],linestyle='',linewidth=2,marker='o',markerfacecolor=[0,0,1],markersize=6) #plot data
	ax2.set_xlabel(xstr)
	ax2.set_ylabel(ystr)
	ax2.set_xlim(np.nanmin(x2)-bf,np.nanmax(x2)+bf)
	ax2.set_ylim(np.nanmin(y2)-bf,np.nanmax(y2)+bf)
	ax2.set_title('Reynolds Creek');
	ax2.yaxis.tick_right()
	ax2.yaxis.set_label_position("right")
	plt.show()

Qp,SWEp,SNDp,dQp,dSWEp,dSNDp,dfs,dls,wy = dfun.get_annual_data()          

# Add Widgets
xdd = widgets.Dropdown(options=['Peak Snow Depth', 'Peak SWE', 'Peak Streamflow','DOY of Peak Snow Depth','DOY of Peak SWE','DOY of Peak Streamflow','DOY of First Snow','DOY of Last Snow'],value='Peak Snow Depth',description='X-axis:',disabled=False,)
ydd = widgets.Dropdown(options=['Peak Snow Depth', 'Peak SWE', 'Peak Streamflow','DOY of Peak Snow Depth','DOY of Peak SWE','DOY of Peak Streamflow','DOY of First Snow','DOY of Last Snow'],value='Peak SWE',description='Y-axis:',disabled=False,)
interact(annualscat,xp=xdd,yp=ydd);

button = Button(description="Save Figure")
display(button)
button.on_click(savfigtm,)