#Creates the Timeseries Widget in the Notebook
# jkroundy@ku.edu July 2020

import numpy as np #This is main numerical library used in python
import matplotlib.pyplot as plt #This is the main plotting library used in python
from ipywidgets import *
import data.datafun as dfun 

#Get Data
Q,SWE,SND,wy,mtime,xstr,tidx,nm = dfun.get_monthly_data()

#Create Initial Plots
fig = plt.figure(figsize=(9,4))

ax1 = fig.add_subplot(1, 2, 1)
x = SND[:,0] # Set the x variable for the plot
y = SWE[:,0] # Set the y variable for the plot
ln1, = ax1.plot(x,y,color=[0,0,0],linestyle='',linewidth=2,marker='o',markerfacecolor=[0,1,0],markersize=6) #plot data
ax1.set_xlabel('Snow Depth [mm]')
ax1.set_ylabel('SWE [mm]')
ax1.set_xlim(np.nanmin(x),np.nanmax(x))
ax1.set_ylim(np.nanmin(y),np.nanmax(y))
ax1.set_title('Sleepers River');

ax2 = fig.add_subplot(1, 2, 2)
x = SND[:,1] # Set the x variable for the plot
y = SWE[:,1] # Set the y variable for the plot
ln2, = ax2.plot(x,y,color=[0,0,0],linestyle='',linewidth=2,marker='o',markerfacecolor=[0,0,1],markersize=6) #plot data
ax2.set_xlabel('Snow Depth [mm]')
ax2.set_ylabel('SWE [mm]')
ax2.set_xlim(np.nanmin(x),np.nanmax(x))
ax2.set_ylim(np.nanmin(y),np.nanmax(y))
ax2.set_title('Reynolds Creek');
ax2.yaxis.tick_right()
ax2.yaxis.set_label_position("right")

def savfigtm(sid):
    xstr = xdd.value
    xstr = xstr.replace(" ", "_")
    ystr = ydd.value
    ystr = ystr.replace(" ", "_")
    
    pname = "rel_monthly_"+xstr+"_"+ystr+".png"
    fname = "./figures/"+pname
    fig.savefig(fname, dpi=150) 
    print("Figure: "+pname+" saved to Figures folder.")

def updatex(xp):
    if xp =="Snow Depth":
        x1 = SND[:,0]
        x2 = SND[:,1]
        xstr = "Snow Depth [mm]"
    elif xp == "SWE":
        x1 = SWE[:,0]
        x2 = SWE[:,1]
        xstr = "SWE [mm]"
    elif xp == "Streamflow":
        x1 = Q[:,0]
        x2 = Q[:,1]
        xstr = "Streamflow [cfs]"
        
    ln1.set_xdata(x1)
    ax1.set_xlim(np.nanmin(x1),np.nanmax(x1))
    ax1.set_xlabel(xstr)
    ln2.set_xdata(x2)
    ax2.set_xlim(np.nanmin(x2),np.nanmax(x2))
    ax2.set_xlabel(xstr)

def updatey(yp):
    if yp =="Snow Depth":
        y1 = SND[:,0]
        y2 = SND[:,1]
        ystr = "Snow Depth [mm]"
    elif yp == "SWE":
        y1 = SWE[:,0]
        y2 = SWE[:,1]
        ystr = "SWE [mm]"
    elif yp == "Streamflow":
        y1 = Q[:,0]
        y2 = Q[:,1]
        ystr = "Streamflow [cfs]"
        
    ln1.set_ydata(y1)
    ax1.set_ylim(np.nanmin(y1),np.nanmax(y1))
    ax1.set_ylabel(ystr)
    ln2.set_ydata(y2)
    ax2.set_ylim(np.nanmin(y2),np.nanmax(y2))
    ax2.set_ylabel(ystr)

xdd = widgets.Dropdown(options=['Snow Depth', 'SWE', 'Streamflow'],value='Snow Depth',description='X-axis:',disabled=False,)
ydd = widgets.Dropdown(options=['Snow Depth', 'SWE', 'Streamflow'],value='SWE',description='Y-axis:',disabled=False,)
interact(updatex,xp=xdd);
interact(updatey,yp=ydd);

button = Button(description="Save Figure")
display(button)
button.on_click(savfigtm,)