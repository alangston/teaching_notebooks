import sys
import time as tsm
import numpy as np #This is main numerical library used in python
import matplotlib.pyplot as plt #This is the main plotting library used in python


def convert2monthly(x,time,sid=-1):
    # Converts given data from a timestep smaller than a month to monthly data
    # INPUTS: x - data to convert, t - time associated with data [year,month,day,hour] for each data point
    #       sid - optional flag to either average (sid < 0) or sum (sid > 0), default is average

    yrs = np.unique(time[:,0])
    nyr = yrs.shape[0]
    xm = np.zeros((nyr*12,))
    xm[:] = np.nan
    mtime = np.zeros((nyr*12,2), dtype=int)
    # mtime = np.zeros((nyr*12,2))

    ij = 0
    for i in range(nyr):
        yidx = (time[:,0] == yrs[i])
        mns = np.unique(time[yidx,1])
        nm = mns.shape[0]
        for j in range(nm):
            idx = yidx * (time[:,1] == mns[j])
            nidx = ~np.isnan(x[idx])
            if nidx.sum() > 0:
                if sid > 0:
                    xm[ij] = np.nansum(x[idx])
                else:
                    xm[ij] = np.nanmean(x[idx])
            mtime[ij,:] = [yrs[i],mns[j]]
            ij = ij + 1
    mtime = mtime[:ij,:]
    xm = xm[:ij]
    return xm,mtime

def get_monthly_data():
    fname = './data/obs/01135300_obs.npz'
    data = np.load(fname)
    nt = data['nt']
    dd = data['time']
    dq = data['Q']
    dqm,mtime = convert2monthly(dq,dd)
    nm = mtime.shape[0]
    Q = np.zeros((nm,2))
    SWE = np.zeros((nm,2))
    SND = np.zeros((nm,2))

    Q[:,0] = dqm
    dswe = data['SWE'].mean(1)
    SWE[:,0],dum = convert2monthly(dswe,dd)
    dsnd = data['SND'].mean(1)
    SND[:,0],dum = convert2monthly(dsnd,dd)

    fname = './data/obs/03600000_obs.npz'
    data = np.load(fname)
    Q[:,1],dum = convert2monthly(data['Q'],dd)
    SWE[:,1],dum = convert2monthly(data['SWE'],dd)
    SND[:,1],dum = convert2monthly(data['SND'],dd)

    #Define Water Years
    yrs = np.unique(mtime[:,0])[1:]
    ny = yrs.shape[0]
    wy = np.zeros((nm,)) # Water Year
    for i in range(ny):
        idx1 = (mtime[:,0] == yrs[i] - 1)*(mtime[:,1] > 9)#get values from Oct-Dec of the water year
        idx2 = (mtime[:,0] == yrs[i])*(mtime[:,1] < 10) #get values from Jan-Sep of the water year
        idx = idx1+idx2 #combine together to get the complete water year
        wy[idx] = yrs[i]


    x = np.arange(nm)
    mstr = np.array(['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'])
    xstr = np.empty((nm,),dtype="|U8")
    for i in range(nm):
        xstr[i] = mstr[mtime[i,1]-1]+'\n'+str(mtime[i,0])
    tidx = (mtime[:,1] == 10) + (mtime[:,1] == 4)
    
    return Q,SWE,SND,wy,mtime,xstr,tidx,nm


def get_daily_data():
	#Snow Course
	fname = './data/obs/01135300_obs.npz'
	data = np.load(fname)
	nt = data['nt']
	ng = data['ng']
	dtime = data['time']
	Qs = data['Q']
	SWEs = data['SWE']
	SNDs = data['SND']

	#Snotel
	fname = './data/obs/03600000_obs.npz'
	data = np.load(fname)
	Qr = data['Q']
	SWEr = data['SWE']
	SNDr = data['SND'] 

	#Define Water Years
	yrs = np.unique(dtime[:,0])[1:]
	ny = yrs.shape[0]
	wy = np.zeros((nt,)) # Water Year
	for i in range(ny):
	    idx1 = (dtime[:,0] == yrs[i] - 1)*(dtime[:,1] > 9)#get values from Oct-Dec of the water year
	    idx2 = (dtime[:,0] == yrs[i])*(dtime[:,1] < 10) #get values from Jan-Sep of the water year
	    idx = idx1+idx2 #combine together to get the complete water year
	    wy[idx] = yrs[i]


	x = np.arange(nt)
	mstr = np.array(['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'])
	xstr = np.empty((nt,),dtype="|U8")
	for i in range(nt):
	    xstr[i] = mstr[dtime[i,1]-1]+'\n'+str(dtime[i,0])
	tidx = (dtime[:,2] == 1)

	return Qs,Qr,SNDs,SNDr,SWEs,SWEr,dtime,wy,nt,ng,x,xstr,tidx


def get_annual_data():
	#Get Data
	fname = './data/obs/01135300_obs.npz'
	data = np.load(fname)
	nt = data['nt']
	Q = np.zeros((nt,2))
	SWE = np.zeros((nt,2))
	SND = np.zeros((nt,2))
	dtime = data['time']
	Q[:,0] = data['Q']
	SWE[:,0] = data['SWE'].mean(1)
	SND[:,0] = data['SND'].mean(1)

	fname = './data/obs/03600000_obs.npz'
	data = np.load(fname)
	Q[:,1] = data['Q']
	SWE[:,1] = data['SWE']
	SND[:,1] = data['SND']

	#Get Water year Statistics
	yrs = np.unique(dtime[:,0])[1:]
	ny = yrs.shape[0]
	wy = np.zeros((ny,2)) # Water Year
	Qp = np.zeros((ny,2)) # Peak Streamflow WY [cfs]
	SWEp = np.zeros((ny,2)) # Peak SWE WY [mm]
	SNDp = np.zeros((ny,2)) # Peak Snow Depth WY [mm]
	dQp = np.zeros((ny,2)) # Doy of Peak Streamflow
	dSWEp = np.zeros((ny,2)) # Doy of Peak SWE
	dSNDp = np.zeros((ny,2)) # Doy of Peak Snow Depth
	dfs = np.zeros((ny,2)) # Doy of First Snow
	dls = np.zeros((ny,2)) # Doy of Last Snow
	for i in range(ny):
		idx1 = (dtime[:,0] == yrs[i] - 1)*(dtime[:,1] > 9)#get values from Oct-Dec of the water year
		idx2 = (dtime[:,0] == yrs[i])*(dtime[:,1] < 10) #get values from Jan-Sep of the water year
		idx = idx1+idx2 #combine together to get the complete water year
		dy = dtime[idx,-1]
		wy[i] = yrs[i]
		for j in range(2):
			dq = Q[idx,j]
			dsw = SWE[idx,j]
			dsd = SND[idx,j]
			mid = np.argmax(dq)
			Qp[i,j] = dq[mid]
			dQp[i,j] = dy[mid]
			mid = np.argmax(dsw)
			SWEp[i,j] = dsw[mid]
			dSWEp[i,j] = dy[mid]
			mid = np.argmax(dsd)
			SNDp[i,j] = dsd[mid]
			dSNDp[i,j] = dy[mid]
			nidx = ~np.isnan(dsd)
			ddsd = dsd[nidx]
			ddy = dy[nidx]
			fidx = ddsd > 0
			dfs[i,j] = ddy[fidx][0]
			dls[i,j] = ddy[fidx][-1]

	return Qp,SWEp,SNDp,dQp,dSWEp,dSNDp,dfs,dls,wy


    