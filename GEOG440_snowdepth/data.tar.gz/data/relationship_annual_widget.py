#Creates the Daily Snow Measurment Widget in the Notebook
# jkroundy@ku.edu July 2020

import numpy as np #This is main numerical library used in python
import matplotlib.pyplot as plt #This is the main plotting library used in python
from ipywidgets import *
import data.datafun as dfun

#Widget functions
def savfigtm(sid):
    xstr = xdd.value
    xstr = xstr.replace(" ", "_")
    ystr = ydd.value
    ystr = ystr.replace(" ", "_")
    
    pname = "rel_annual_"+xstr+"_"+ystr+".png"
    fname = "./figures/"+pname
    fig.savefig(fname, dpi=150) 
    print("Figure: "+pname+" saved to Figures folder.")

def updatex(xp):
    if xp =="Peak Snow Depth":
        x1 = SNDp[:,0]
        x2 = SNDp[:,1]
        xstr = "Peak Snow Depth [mm]"
    elif xp == "Peak SWE":
        x1 = SWEp[:,0]
        x2 = SWEp[:,1]
        xstr = "Peak SWE [mm]"
    elif xp == "Peak Streamflow":
        x1 = Qp[:,0]
        x2 = Qp[:,1]
        xstr = "Peak Streamflow [cfs]"
    elif xp == "DOY of Peak Streamflow":
        x1 = dQp[:,0]
        x2 = dQp[:,1]
        xstr = "DOY of Peak Streamflow"        
    elif xp == "DOY of Peak Snow Depth":
        x1 = dSNDp[:,0]
        x2 = dSNDp[:,1]
        xstr = "DOY of Peak Snow Depth"
    elif xp == "DOY of Peak SWE":
        x1 = dSWEp[:,0]
        x2 = dSWEp[:,1]
        xstr = "DOY of Peak SWE"
    elif xp == "DOY of First Snow":
        x1 = dfs[:,0]
        x2 = dfs[:,1]
        xstr = "DOY of First Snow"
    elif xp == "DOY of Last Snow":
        x1 = dls[:,0]
        x2 = dls[:,1]
        xstr = "DOY of Last Snow"
    ln1.set_xdata(x1)
    ax1.set_xlim(np.nanmin(x1)-bf,np.nanmax(x1)+bf)
    ax1.set_xlabel(xstr)
    ln2.set_xdata(x2)
    ax2.set_xlim(np.nanmin(x2)-bf,np.nanmax(x2)+bf)
    ax2.set_xlabel(xstr)

def updatey(yp):
    if yp =="Peak Snow Depth":
        y1 = SNDp[:,0]
        y2 = SNDp[:,1]
        ystr = "Peak Snow Depth [mm]"
    elif yp == "Peak SWE":
        y1 = SWEp[:,0]
        y2 = SWEp[:,1]
        ystr = "Peak SWE [mm]"
    elif yp == "Peak Streamflow":
        y1 = Qp[:,0]
        y2 = Qp[:,1]
        ystr = "Peak Streamflow [cfs]"
    elif yp == "DOY of Peak Streamflow":
        y1 = dQp[:,0]
        y2 = dQp[:,1]
        ystr = "DOY of Peak Streamflow"        
    elif yp == "DOY of Peak Snow Depth":
        y1 = dSNDp[:,0]
        y2 = dSNDp[:,1]
        ystr = "DOY of Peak Snow Depth"
    elif yp == "DOY of Peak SWE":
        y1 = dSWEp[:,0]
        y2 = dSWEp[:,1]
        ystr = "DOY of Peak SWE"
    elif yp == "DOY of First Snow":
        y1 = dfs[:,0]
        y2 = dfs[:,1]
        ystr = "DOY of First Snow"
    elif yp == "DOY of Last Snow":
        y1 = dls[:,0]
        y2 = dls[:,1]
        ystr = "DOY of Last Snow"
    ln1.set_ydata(y1)
    ax1.set_ylim(np.nanmin(y1)-bf,np.nanmax(y1)+bf)
    ax1.set_ylabel(ystr)
    ln2.set_ydata(y2)
    ax2.set_ylim(np.nanmin(y2)-bf,np.nanmax(y2)+bf)
    ax2.set_ylabel(ystr)


#Get Data
fname = './data/obs/01135300_obs.npz'
data = np.load(fname)
nt = data['nt']
Q = np.zeros((nt,2))
SWE = np.zeros((nt,2))
SND = np.zeros((nt,2))
dtime = data['time']
Q[:,0] = data['Q']
SWE[:,0] = data['SWE'].mean(1)
SND[:,0] = data['SND'].mean(1)

fname = './data/obs/03600000_obs.npz'
data = np.load(fname)
Q[:,1] = data['Q']
SWE[:,1] = data['SWE']
SND[:,1] = data['SND']

#Get Water year Statistics
yrs = np.unique(dtime[:,0])[1:]
ny = yrs.shape[0]
wy = np.zeros((ny,2)) # Water Year
Qp = np.zeros((ny,2)) # Peak Streamflow WY [cfs]
SWEp = np.zeros((ny,2)) # Peak SWE WY [mm]
SNDp = np.zeros((ny,2)) # Peak Snow Depth WY [mm]
dQp = np.zeros((ny,2)) # Doy of Peak Streamflow
dSWEp = np.zeros((ny,2)) # Doy of Peak SWE
dSNDp = np.zeros((ny,2)) # Doy of Peak Snow Depth
dfs = np.zeros((ny,2)) # Doy of First Snow
dls = np.zeros((ny,2)) # Doy of Last Snow
for i in range(ny):
    idx1 = (dtime[:,0] == yrs[i] - 1)*(dtime[:,1] > 9)#get values from Oct-Dec of the water year
    idx2 = (dtime[:,0] == yrs[i])*(dtime[:,1] < 10) #get values from Jan-Sep of the water year
    idx = idx1+idx2 #combine together to get the complete water year
    dy = dtime[idx,-1]
    wy[i] = yrs[i]
    for j in range(2):
        dq = Q[idx,j]
        dsw = SWE[idx,j]
        dsd = SND[idx,j]
        mid = np.argmax(dq)
        Qp[i,j] = dq[mid]
        dQp[i,j] = dy[mid]
        mid = np.argmax(dsw)
        SWEp[i,j] = dsw[mid]
        dSWEp[i,j] = dy[mid]
        mid = np.argmax(dsd)
        SNDp[i,j] = dsd[mid]
        dSNDp[i,j] = dy[mid]
        nidx = ~np.isnan(dsd)
        ddsd = dsd[nidx]
        ddy = dy[nidx]
        fidx = ddsd > 0
        dfs[i,j] = ddy[fidx][0]
        dls[i,j] = ddy[fidx][-1]
            

#Create Initial Plots
fig = plt.figure(figsize=(9,4))
bf = 10
ax1 = fig.add_subplot(1, 2, 1)
x = SNDp[:,0] # Set the x variable for the plot
y = SWEp[:,0] # Set the y variable for the plot
ln1, = ax1.plot(x,y,color=[0,0,0],linestyle='',linewidth=2,marker='o',markerfacecolor=[0,1,0],markersize=6) #plot data
ax1.set_xlabel('Peak Snow Depth [mm]')
ax1.set_ylabel('Peak SWE [mm]')
ax1.set_xlim(np.nanmin(x)-bf,np.nanmax(x)+bf)
ax1.set_ylim(np.nanmin(y)-bf,np.nanmax(y)+bf)
ax1.set_title('Sleepers River');

ax2 = fig.add_subplot(1, 2, 2)
x = SNDp[:,1] # Set the x variable for the plot
y = SWEp[:,1] # Set the y variable for the plot
ln2, = ax2.plot(x,y,color=[0,0,0],linestyle='',linewidth=2,marker='o',markerfacecolor=[0,0,1],markersize=6) #plot data
ax2.set_xlabel('Peak Snow Depth [mm]')
ax2.set_ylabel('Peak SWE [mm]')
ax2.set_xlim(np.nanmin(x)-bf,np.nanmax(x)+bf)
ax2.set_ylim(np.nanmin(y)-bf,np.nanmax(y)+bf)
ax2.set_title('Reynolds Creek');
ax2.yaxis.tick_right()
ax2.yaxis.set_label_position("right")

# Add Widgets
xdd = widgets.Dropdown(options=['Peak Snow Depth', 'Peak SWE', 'Peak Streamflow','DOY of Peak Snow Depth','DOY of Peak SWE','DOY of Peak Streamflow','DOY of First Snow','DOY of Last Snow'],value='Peak Snow Depth',description='X-axis:',disabled=False,)
ydd = widgets.Dropdown(options=['Peak Snow Depth', 'Peak SWE', 'Peak Streamflow','DOY of Peak Snow Depth','DOY of Peak SWE','DOY of Peak Streamflow','DOY of First Snow','DOY of Last Snow'],value='Peak SWE',description='Y-axis:',disabled=False,)
interact(updatex,xp=xdd);
interact(updatey,yp=ydd);

button = Button(description="Save Figure")
display(button)
button.on_click(savfigtm,)