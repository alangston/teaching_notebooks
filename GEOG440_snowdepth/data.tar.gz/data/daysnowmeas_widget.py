#Creates the Daily Snow Measurment Widget in the Notebook
# jkroundy@ku.edu July 2020

import numpy as np #This is main numerical library used in python
import matplotlib.pyplot as plt #This is the main plotting library used in python
from ipywidgets import *
import data.datafun as dfun

#Widget Functions
def tdupdate(yr):
    idx = (wy == yr)
    xx = x[idx]
    ax1.set_xlim(xx.min(),xx.max())
    ax2.set_xlim(xx.min(),xx.max())
    ax3.set_xlim(xx.min(),xx.max())
    ax4.set_xlim(xx.min(),xx.max())
    fig.canvas.draw_idle()  

def savfigms(sid):
	swyr = year.value
	pname = "snow_measurment_"+str(swyr)+".png"
	fname = "./figures/"+pname
	fig.savefig(fname, dpi=150) 
	print("Figure: "+pname+" saved to Figures folder.")

#Reads Data
Qs,Qr,SNDs,SNDr,SWEs,SWEr,dtime,wy,nt,ng,x,xstr,tidx = dfun.get_daily_data()

#Create Initial Plots
gstr = np.array(['R1A','R-7','R-24','R-25','R-10','R-8','R-19'])
fig = plt.figure(figsize=(9,11))
ax1 = fig.add_subplot(4, 1, 1)
x = np.arange(nt)
for i in range(ng):
    ax1.plot(x,SNDs[:,i],label=gstr[i])
ax1.set_ylabel('Snow Depth [mm]')
ax1.set_xticks(x[tidx])
ax1.set_xticklabels(xstr[tidx])
ax1.set_xlim(x.min(),x.max())
ax1.set_ylim(np.nanmin(SNDs),np.nanmax(SNDs))
ax1.set_title('Snow Course - Sleepers River')
plt.legend(loc=1,ncol=2,fontsize=10);  

ax2 = fig.add_subplot(4, 1, 2)
ax2.plot(x,SNDr,color='#69ef7b')
ax2.set_ylabel('Snow Depth [mm]')
ax2.set_xticks(x[tidx])
ax2.set_xticklabels(xstr[tidx])
ax2.set_xlim(x.min(),x.max())
ax2.set_ylim(np.nanmin(SNDr),np.nanmax(SNDr))
ax2.set_title('SNOTEL - Reynolds Creek')

ax3 = fig.add_subplot(4, 1, 3)
x = np.arange(nt)
for i in range(ng):
    ax3.plot(x,SWEs[:,i],label=gstr[i])
ax3.set_ylabel('SWE [mm]')
ax3.set_xticks(x[tidx])
ax3.set_xticklabels(xstr[tidx])
ax3.set_xlim(x.min(),x.max())
ax3.set_ylim(np.nanmin(SWEs),np.nanmax(SWEs))
ax3.set_title('Snow Course - Sleepers River')
plt.legend(loc=1,ncol=2,fontsize=10); 

ax4 = fig.add_subplot(4, 1, 4)
ax4.plot(x,SWEr,color='#69ef7b')
ax4.set_ylabel('SWE [mm]')
ax4.set_xticks(x[tidx])
ax4.set_xticklabels(xstr[tidx])
ax4.set_xlim(x.min(),x.max())
ax4.set_ylim(np.nanmin(SWEr),np.nanmax(SWEr))
ax4.set_title('SNOTEL - Reynolds Creek')
plt.subplots_adjust(hspace=0.5)

#Loads Widgets
year = widgets.IntSlider(min=2000, max=2014, step=1, value=2008)
interact(tdupdate, yr=year );
button = Button(description="Save Figure")
display(button)
button.on_click(savfigms,)