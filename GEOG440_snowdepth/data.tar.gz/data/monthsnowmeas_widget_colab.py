#Creates the Timeseries Widget in the Notebook
# jkroundy@ku.edu July 2020

import numpy as np #This is main numerical library used in python
import matplotlib.pyplot as plt #This is the main plotting library used in python
from ipywidgets import *
import data.datafun as dfun 

#Widget Functions
def savfigtm(sid):
    swyr = year.value
    pname = "snow_monthly_"+str(swyr)+".png"
    fname = "./figures/"+pname
    fig.savefig(fname, dpi=150) 
    print("Saved Figure: "+pname)


def mnth_plt(yr,sid,rid):
    #Get time frame for plot
    idx = (wy > yr -2)*(wy < yr + 2)
    x = np.arange(nm)
    xstx = xstr[idx*tidx]
    xidx = x[idx*tidx]
    x = x[idx]
    
    #Create Initial Plots
    global fig
    fig = plt.figure(figsize=(9,9));
    ax1 = fig.add_subplot(3, 1, 3)
    lineS1, = ax1.plot(x,Q[idx,0],color='#f1cbd5',label='Sleepers')
    lineS1.set_visible(sid)
    lineR1, = ax1.plot(x,Q[idx,1],color='#821f48',label='Reynolds')
    lineR1.set_visible(rid)
    ax1.set_ylabel('Streamflow [cfs]')
    ax1.set_xticks(xidx)
    ax1.set_xticklabels(xstx)
    ax1.set_xlim(x.min(),x.max())
    ax1.set_ylim(np.nanmin(Q),np.nanmax(Q))
    plt.legend(loc=1,ncol=2,fontsize=10); 
    
    ax2 = fig.add_subplot(3, 1, 2)
    lineS2, = ax2.plot(x,SWE[idx,0],color='#69ef7b',label='Sleepers')
    lineS2.set_visible(sid)
    lineR2, = ax2.plot(x,SWE[idx,1],color='#02531d',label='Reynolds')
    lineR2.set_visible(rid)
    ax2.set_ylabel('SWE [mm]')
    ax2.set_xticks(xidx)
    ax2.set_xticklabels(xstx)
    ax2.set_xlim(x.min(),x.max())
    ax2.set_ylim(np.nanmin(SWE),np.nanmax(SWE))
    plt.legend(loc=1,ncol=2,fontsize=10); 

    ax3 = fig.add_subplot(3, 1, 1)
    lineS3, = ax3.plot(x,SND[idx,0],color='#79e3f9',label='Sleepers')
    lineS3.set_visible(sid)
    lineR3, = ax3.plot(x,SND[idx,1],color='#256676',label='Reynolds')
    lineR3.set_visible(rid)
    ax3.set_ylabel('Snow Depth [mm]')
    ax3.set_xticks(xidx)
    ax3.set_xticklabels(xstx)
    ax3.set_xlim(x.min(),x.max())
    ax3.set_ylim(np.nanmin(SND),np.nanmax(SND))
    plt.legend(loc=1,ncol=2,fontsize=10); 
    plt.subplots_adjust(hspace=0.3)
    plt.show()

Q,SWE,SND,wy,mtime,xstr,tidx,nm = dfun.get_monthly_data()


# Activate Widgets
year = widgets.IntSlider(min=2001, max=2013, step=1, value=2001)
slp = widgets.Checkbox(value=True, description='Sleepers River', disabled=False, indent=False)
rey = widgets.Checkbox(value=True, description='Reynolds Creek', disabled=False, indent=False)
interact(mnth_plt, yr=year, sid=slp, rid=rey);


button = Button(description="Save Figure")
display(button)
button.on_click(savfigtm,)



